#include <stdio.h>

int main() {
    char son[100];
    printf("Sonni kiriting: ");
    scanf("%s", son);

    printf("Output:\n%c\n", son[0]);
    return 0;
}
