#include <stdio.h>
#include <math.h>

int main() {
    int n;
    printf("Input: ");
    scanf("%d", &n);

    long long term = 0, sum = 0;

    printf("Output:\n");
    for (int i = 1; i <= n; i++) {
        term = term * 10 + 1; 
        printf("%lld", term); 
        sum += term;

        if (i != n) {
            printf("+");
        }
    }

    printf("=%lld\n", sum);

    return 0;
}
